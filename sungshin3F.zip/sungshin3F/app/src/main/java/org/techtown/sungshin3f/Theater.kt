package org.techtown.sungshin3f

data class Theater(
    val iconDrawable: Int,
    val title:String?,
    //설명이 영어로 Explanation
    val exp:String?
)
