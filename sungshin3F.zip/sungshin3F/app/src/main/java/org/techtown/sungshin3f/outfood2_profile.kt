package org.techtown.sungshin3f

data class outfood2_profile (val name:String?, val locate: String?, val time: String?, val star: String?, val heart: String?){
}